Put the pre-wedding video here (e.g. prewedding.mp4).
Recommended: H.264 MP4, under ~15MB, 720p is plenty for mobile.
Then set js/config.js -> gallery.video to "assets/video/prewedding.mp4".
