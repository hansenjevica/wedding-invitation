Put pre-wedding photos here (e.g. photo-01.jpg, photo-02.jpg).
Recommended: compress to WebP or JPEG, max ~1600px wide, under 300KB each.
Then list them in js/config.js under gallery.images.
