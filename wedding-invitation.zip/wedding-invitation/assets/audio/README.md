Put the background music file here as music.mp3.
Recommended: under ~3MB, a soft instrumental works best.
js/config.js -> music.src already points to "assets/audio/music.mp3".
