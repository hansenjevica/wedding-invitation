# Hansen & Jevica — Wedding Invitation Website

A mobile-first digital wedding invitation with a live RSVP form backed by
Google Sheets, a real-time wedding-wishes wall, a countdown timer, and
one-tap "Add to Google Calendar" / "Open in Google Maps" buttons.

No build tools, no frameworks, no paid services — just static files
(HTML/CSS/JS) plus a free Google Apps Script backend.

---

## 1. What's in this project

```
wedding-invitation/
├── index.html              ← the whole page (all sections)
├── css/style.css           ← all styling (4 season themes)
├── js/config.js            ← ⭐ EDIT THIS for all wedding details
├── js/script.js            ← behaviour (countdown, RSVP, wishes, etc.)
├── apps-script/Code.gs      ← paste into Google Apps Script (RSVP backend)
├── assets/images/          ← put pre-wedding photos here later
├── assets/video/           ← put pre-wedding video here later
├── assets/audio/           ← put background music (music.mp3) here later
└── README.md                ← this file
```

**You will almost never need to touch `index.html`, `style.css`, or
`script.js`.** Day-to-day edits (names, date, venue, bank account, guest
links) all happen in **`js/config.js`**.

---

## 2. A note on what I could and couldn't do for you

I don't have the ability to log into your GitHub or Google accounts, so I
couldn't actually push this to a repository, click "Deploy" on Apps
Script, or turn on GitHub Pages myself — those steps need your own
credentials. What I *did* do is build the entire, working project so
that all that's left for you is about 15 minutes of clicking through the
two setups below. Everything is copy-paste.

---

## 3. Deploy the website (GitHub Pages) — ~5 minutes

1. Go to [github.com/new](https://github.com/new) and create a new
   repository (e.g. `wedding-invitation`). Keep it **Public** (GitHub
   Pages on a free account requires public repos).
2. Download the project files (provided alongside this README) and
   upload them to the repo:
   - Easiest way: on the repo page, click **Add file → Upload files**,
     drag in everything from the `wedding-invitation` folder (keeping
     the folder structure), and commit.
   - Or, if you use Git locally:
     ```bash
     git clone https://github.com/YOUR-USERNAME/wedding-invitation.git
     cd wedding-invitation
     # copy all the provided files into this folder, keeping subfolders
     git add .
     git commit -m "Wedding invitation site"
     git push
     ```
3. In the repo, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source: Deploy from a branch**,
   **Branch: main**, folder **/ (root)** → **Save**.
5. Wait ~1 minute, then your site is live at:
   ```
   https://YOUR-USERNAME.github.io/wedding-invitation/
   ```

That's it — GitHub Pages will auto-redeploy every time you push changes.

---

## 4. Connect Google Sheets (RSVP database) — ~10 minutes

1. Create a new Google Sheet (sheets.new). Name it something like
   "Wedding RSVP".
2. In the Sheet, go to **Extensions → Apps Script**.
3. Delete any placeholder code in the editor, then paste in the entire
   contents of **`apps-script/Code.gs`** from this project.
4. Click **Save** (the disk icon).
5. Click **Deploy → New deployment**.
   - Click the gear icon next to "Select type" → choose **Web app**.
   - Description: "Wedding RSVP API" (anything you like).
   - **Execute as: Me**
   - **Who has access: Anyone**
   - Click **Deploy**.
6. Google will ask you to authorize the script (since it writes to your
   Sheet) — click **Authorize access**, choose your Google account, and
   if you see an "unverified app" warning, click **Advanced → Go to
   (project name) (unsafe)**. This is expected for personal scripts you
   wrote/pasted yourself.
7. Copy the **Web app URL** shown (it looks like
   `https://script.google.com/macros/s/AKfycb.../exec`).
8. Open **`js/config.js`** in your project and paste it in:
   ```js
   rsvp: {
     scriptURL: "https://script.google.com/macros/s/AKfycb.../exec",
     ...
   }
   ```
9. Push/upload the updated `config.js` to GitHub (see step 3.2). Your
   RSVP form and wishes wall are now live.

**Test it:** open your GitHub Pages link, submit a test RSVP, then check
your Google Sheet — a new row should appear in a tab called `RSVP`
within a couple of seconds. Refresh the site and your test message
should appear in the Wedding Wishes wall.

> **If you ever edit `Code.gs` later:** you must create a **new
> deployment version** for changes to take effect — go to **Deploy →
> Manage deployments → Edit (pencil icon) → Version: New version →
> Deploy**. Editing the script alone does not update the live URL.

---

## 5. Editing wedding details

Open **`js/config.js`**. Every field is commented. The main ones:

| Field | What it controls |
|---|---|
| `couple.*` | Names shown throughout the site |
| `event.dateTimeISO` | Drives the countdown **and** the calendar button — keep the `+07:00` (or your local UTC offset) accurate |
| `event.venueAddress` / `mapsQuery` | Google Maps link + embed |
| `rsvp.scriptURL` | Your Apps Script Web App URL (step 4) |
| `gift.*` | Bank details and gift address shown in the Gift section |
| `music.src` | Path to your background music file |
| `gallery.images` / `gallery.video` | Photos/video once you have them |

After editing, commit and push the file (or re-upload it via GitHub's
web UI) — Pages redeploys automatically.

---

## 6. Personalised guest links

Share a link like:

```
https://YOUR-USERNAME.github.io/wedding-invitation/?to=Ade%20Fitriyani
```

- The `to=` value is shown on the opening cover ("Dear Ade Fitriyani...")
  and pre-fills the RSVP name field.
- To build one for each guest, just replace `Ade%20Fitriyani` with their
  name (spaces become `%20` or `+`).
- **Once a guest submits the RSVP form from their link, that link locks
  on their device/browser** — the form becomes read-only and shows a
  "thank you, we've already received your RSVP" message instead of
  letting them resubmit.
  - This lock is stored in the guest's own browser (`localStorage`), not
    on a server. It's the standard approach for invitation sites like
    this and works well in practice, but a guest could technically still
    submit again from a different browser/device. If you need a
    stricter, server-verified one-response-per-guest guarantee, that
    would require generating a unique token per guest link and
    validating it in Apps Script — I'm happy to build that as a v2 if
    it matters for your event.

---

## 7. Adding photos, video, and music later

1. Drop files into `assets/images/`, `assets/video/`, `assets/audio/`.
2. In `js/config.js`, list them:
   ```js
   gallery: {
     images: ["assets/images/photo-01.jpg", "assets/images/photo-02.jpg"],
     video: "assets/video/prewedding.mp4"
   },
   music: { src: "assets/audio/music.mp3" }
   ```
3. **Before uploading, optimise for web:**
   - Photos: compress to JPEG/WebP, ~1600px on the long edge, under
     ~300KB each (tools: squoosh.app, TinyPNG).
   - Video: H.264 MP4, 720p, under ~15MB (tools: HandBrake).
   - Music: MP3, under ~3MB, ideally an instrumental loop.
4. The gallery placeholder section currently shows a "coming soon" note
   — once you add real images, replace that block in `index.html`
   (search for `id="galleryPlaceholder"`) with an `<img>`/`<video>`
   grid, or ask me to wire it up for you.

---

## 8. Exporting / managing RSVPs

Your Google Sheet **is** the database — no export step needed:

- Every submission is a new row (Timestamp, Name, Attendance, Guests,
  Message).
- Use Sheets' built-in sort/filter, or **File → Download** to get a
  `.xlsx` or `.csv` copy any time.
- To get a total guest count, add a formula cell:
  `=SUMIF(RSVP!C:C,"Attending",RSVP!D:D)`

---

## 9. Troubleshooting

- **RSVP submits but nothing appears in the Sheet:** double-check
  `rsvp.scriptURL` in `config.js` has no typos, and that the Apps Script
  deployment's access is set to "Anyone."
- **Wishes wall stays empty:** open `YOUR_SCRIPT_URL?action=list` in a
  browser directly — it should show JSON. If it errors, redeploy the
  Apps Script (see the note in step 4).
- **Countdown looks off:** confirm `event.dateTimeISO` includes the
  correct UTC offset for your venue's timezone (Gading Serpong is
  `+07:00`).
- **Calendar button opens the wrong time:** same cause as above — the
  calendar event is generated directly from `dateTimeISO`.

---

## 10. Requirements checklist

- [x] RSVP form (name, attendance, guest count, message) syncing to
      Google Sheets in real time, one row per submission
- [x] Wedding Wishes wall showing name + message, auto-refreshing
      (near real-time polling)
- [x] Countdown timer — days / hours / minutes / seconds
- [x] Clickable venue address opening Google Maps
- [x] Clickable date/time opening Google Calendar with title, date,
      time, venue, and description pre-filled
- [x] Editable placeholders for groom, bride, venue, date/time
- [x] Gift section ("Wanna give us some gifts?") with bank + address
      placeholders, elegant/minimal styling
- [x] Four seasonal themes in order — Summer (cover) → Spring (couple +
      countdown) → Fall (event details + map) → Winter (RSVP, wishes,
      gift, closing)
- [x] Mobile-first, responsive, smooth scrolling
- [x] Opening cover, Bride & Groom, Countdown, Event details, Maps,
      RSVP, Wishes, Gift, Closing sections
- [x] Reserved section for photos/video, with optimisation guidance
- [x] Floating music button + fade-in scroll animations
- [x] Personalised, shareable guest links with post-submit lock
- [x] GitHub Pages-ready static files
- [x] Google Apps Script backend code
- [x] Maintenance instructions (this file)
